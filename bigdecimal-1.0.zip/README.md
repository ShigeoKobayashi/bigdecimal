# bigdecimal
[Variable precision decimal arithmetic C/C++ libraly](http://www.tinyforest.jp/oss/bigdecimal.html)

The Bigdecimal is a variable precision decimal arithmetic C/C++ library. 
Using Bigdecimal, you can obtain any number of significant digits in your computation. 
For more informations and usage of Bigdecimal,refer to bigdecimal.html on your browser.

This software can be redistributed under GNU Lesser General Public License.

To build this software on Linux => see makefile    
To build this software on Windows => create Visual studio solution,and add source files.  
To use this library => include bigdecimal.h in your source codes(see vpc.c) and link appropriate library files.  
This software has been tested on Windows-10(32-bit & 64-bit) and Linux(32-bit CentOS-5 & 64-bit CentOS-7). 

